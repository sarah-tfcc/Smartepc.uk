SmartEPC.uk — Launch Kit (GoDaddy + Netlify)
================================================

Files included
--------------
- index.html (single-page site)
- robots.txt
- sitemap.xml
- favicon.ico, favicon-256.png
- og-image.jpg
- README (this file)

What you need
-------------
- Netlify account (free)
- GoDaddy login for the domain smartepc.uk

1) Deploy to Netlify (drag & drop)
----------------------------------
1. Log in to Netlify → "Add new site" → "Deploy manually"
2. Drag this entire folder into the drop zone
3. Wait for the deploy to finish
4. In Site settings → Domain management → Add custom domain → type: smartepc.uk
5. Netlify will show the DNS records you need

2) Add DNS in GoDaddy
---------------------
1. Go to GoDaddy → My Products → smartepc.uk → DNS
2. Add these records (use exact values from Netlify prompt if different):

   Type: A
   Name: @
   Value: 75.2.60.5
   TTL: 1 hour

   Type: A
   Name: @
   Value: 99.83.190.102
   TTL: 1 hour

   Type: CNAME
   Name: www
   Value: your-netlify-site.netlify.app
   TTL: 1 hour

3. Back in Netlify, set **smartepc.uk** as the **primary domain**
4. Click "Verify DNS" then "Provision certificate" to enable HTTPS

Tip: If you already used GoDaddy's forwarding or other DNS, remove conflicting A/CNAME records first.

3) Post-launch checks
---------------------
- Visit: https://smartepc.uk
- Test mobile, tel:, mailto:, and WhatsApp buttons
- Submit https://smartepc.uk/sitemap.xml to Google Search Console

Edits
-----
- Pricing is defined once in index.html
- Contact details are already set to: Sarah.tfcc@gmail.com and 07865 766950
- Elmhurst and PI statements are already included
- To change branding colours, edit the CSS variables in :root

Support
-------
If you want a bookings spreadsheet + auto-confirm emails, add a form service later (Netlify Forms, Tally, or Google Forms).
